// Custom module: logger.js
const fs = require("fs");
const path = require("path");

const LOG_FILE = path.join(__dirname, "../data/server.log");

function log(level, message) {
  const timestamp = new Date().toISOString();
  const entry = `[${timestamp}] [${level.toUpperCase()}] ${message}\n`;
  fs.appendFileSync(LOG_FILE, entry);
  console.log(entry.trim());
}

function readLogs() {
  if (!fs.existsSync(LOG_FILE)) return "No logs yet.";
  return fs.readFileSync(LOG_FILE, "utf8");
}

function clearLogs() {
  fs.writeFileSync(LOG_FILE, "");
}

module.exports = { log, readLogs, clearLogs };
