// Custom module: stats.js — server request statistics tracker
const os = require("os");

let requestCount = 0;
const startTime = Date.now();

function increment() { requestCount++; }

function getStats() {
  return {
    uptime_seconds: Math.floor((Date.now() - startTime) / 1000),
    total_requests: requestCount,
    platform: os.platform(),
    hostname: os.hostname(),
    node_version: process.version,
  };
}

module.exports = { increment, getStats };
