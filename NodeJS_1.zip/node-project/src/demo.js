// demo.js — standalone script to verify fs + modules without starting server
const fs   = require("fs");
const path = require("path");
const os   = require("os");
const { log, readLogs, clearLogs } = require("../modules/logger");
const { getStats } = require("../modules/stats");

console.log("=== Node.js Fundamentals Demo ===\n");

// fs: write
const demoFile = path.join(__dirname, "../data/demo.txt");
fs.writeFileSync(demoFile, "Hello from fs.writeFileSync!\n");
console.log("fs.writeFileSync → wrote demo.txt");

// fs: append
fs.appendFileSync(demoFile, `Appended at ${new Date().toISOString()}\n`);
console.log("fs.appendFileSync → appended to demo.txt");

// fs: read
const content = fs.readFileSync(demoFile, "utf8");
console.log("fs.readFileSync →\n" + content);

// built-in os module
console.log(`os.platform() → ${os.platform()}`);
console.log(`os.hostname() → ${os.hostname()}`);

// custom module: logger
log("info", "Demo script executed successfully");
log("warn", "This is a test warning");

// custom module: stats
console.log("\nStats:", getStats());

console.log("\nLogs written to data/server.log:");
console.log(readLogs());
