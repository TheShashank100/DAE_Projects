// index.js — entry point
const http = require("http");     // built-in: http
const path = require("path");     // built-in: path
const fs   = require("fs");       // built-in: fs

// Custom modules imported here
const { log, readLogs } = require("../modules/logger");
const { increment, getStats } = require("../modules/stats");

// ── fs: write a startup file ──────────────────────────────────────────────────
const startupFile = path.join(__dirname, "../data/startup.txt");
fs.writeFileSync(startupFile, `Server started at ${new Date().toISOString()}\n`);
const startupMsg = fs.readFileSync(startupFile, "utf8").trim();

// ── HTTP server ───────────────────────────────────────────────────────────────
const PORT = 3000;

const server = http.createServer((req, res) => {
  increment();
  log("info", `${req.method} ${req.url}`);

  const sendJSON = (data, status = 200) => {
    res.writeHead(status, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data, null, 2));
  };

  if (req.url === "/" && req.method === "GET") {
    sendJSON({ message: "Node.js server is running.", startup: startupMsg });

  } else if (req.url === "/stats") {
    sendJSON(getStats());

  } else if (req.url === "/logs") {
    res.writeHead(200, { "Content-Type": "text/plain" });
    res.end(readLogs());

  } else {
    sendJSON({ error: "Route not found." }, 404);
  }
});

server.listen(PORT, () => {
  log("info", `Server listening on http://localhost:${PORT}`);
});
